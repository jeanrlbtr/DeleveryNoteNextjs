import { PurchaseOrder } from '@/components/page';
async function DeleveryNote() {
   return <PurchaseOrder />;
}

export default DeleveryNote;
