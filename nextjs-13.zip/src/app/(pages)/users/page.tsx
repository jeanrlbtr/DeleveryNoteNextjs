import User from '@/components/page/User/User';

const UserPage = async () => {
   return <User />;
};

export default UserPage;
