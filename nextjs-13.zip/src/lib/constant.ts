export const queryClientOptions = {
   defaultOptions: {
      queries: {
         refetchOnWindowFocus: false,
      },
   },
};
