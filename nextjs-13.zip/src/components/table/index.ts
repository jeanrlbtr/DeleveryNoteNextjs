import TableLoading from './TableLoading';

export { TableLoading };
